import json, os, subprocess, threading, time, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

HOME = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'ZYADGroupPlayout'
HOME.mkdir(parents=True, exist_ok=True)
CONFIG = HOME / 'channels.json'
FFMPEG = Path(__file__).resolve().parent / 'ffmpeg.exe'
FFMPEG = str(FFMPEG) if FFMPEG.exists() else 'ffmpeg'

def default(i):
    return {'name': f'Channel {i+1}', 'files': [], 'ip': f'239.1.1.{i+1}', 'port': 1234+i,
            'video_kbps': 2000, 'audio_kbps': 128, 'mode': 'copy', 'index': 0,
            'position': 0.0, 'loop': True, 'resume': True, 'text': ''}

def load():
    try:
        raw=json.loads(CONFIG.read_text(encoding='utf-8'))
        return [{**default(i), **raw[i]} for i in range(32)]
    except (OSError, ValueError, IndexError, TypeError):
        return [default(i) for i in range(32)]
channels=load()
lock=threading.RLock()
active=set()
processes={}
started={}

def save():
    with lock:
        tmp=CONFIG.with_suffix('.tmp')
        tmp.write_text(json.dumps(channels, indent=2, ensure_ascii=False), encoding='utf-8')
        tmp.replace(CONFIG)

def args(c, video):
    import ipaddress
    ipaddress.ip_address(c['ip'])
    port=int(c['port'])
    if not 1 <= port <= 65535: raise ValueError('Invalid port')
    a=[FFMPEG, '-hide_banner', '-loglevel', 'error', '-nostdin', '-re']
    if c['position'] > 0: a += ['-ss', str(c['position'])]
    a += ['-i', video, '-map', '0:v:0', '-map', '0:a:0?']
    if c['mode']=='copy' and not c['text']:
        a+=['-c', 'copy']
    else:
        a+=['-c:v', 'libx264', '-preset', 'veryfast', '-b:v', str(int(c['video_kbps']))+'k',
            '-maxrate', str(int(c['video_kbps']))+'k', '-bufsize', str(int(c['video_kbps'])*2)+'k',
            '-c:a', 'aac', '-b:a', str(int(c['audio_kbps']))+'k']
        if c['text']:
            f=HOME / ('text_'+str(channels.index(c)+1)+'.txt')
            f.write_text(c['text'], encoding='utf-8')
            escaped=str(f).replace('\\','/').replace(':','\\:')
            a+=['-vf', "drawtext=textfile='"+escaped+"':fontcolor=white:fontsize=26:x=20:y=20"]
    a+=['-f', 'mpegts', f"udp://{c['ip']}:{port}?pkt_size=1316"]
    return a

def work(i):
    c=channels[i]
    while i in active and c['files']:
        idx=int(c['index']) % len(c['files'])
        video=c['files'][idx]
        if not Path(video).is_file():
            root.after(0, lambda: messagebox.showerror('Missing file', video))
            break
        try:
            p=subprocess.Popen(args(c,video),stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            processes[i]=p
            started[i]=time.monotonic()
            code=p.wait()
        except (OSError, ValueError) as e:
            msg=str(e)
            root.after(0, lambda m=msg: messagebox.showerror('FFmpeg error',m))
            break
        finally:
            processes.pop(i,None)
            started.pop(i,None)
        if i not in active: break
        if code!=0:
            root.after(0, lambda n=i+1: messagebox.showwarning('Stream stopped',f'Channel {n}: FFmpeg exited with an error. Check codec and settings.'))
            break
        c['index']=idx+1
        c['position']=0
        if c['index']>=len(c['files']):
            if c['loop']: c['index']=0
            else: break
        save()
    active.discard(i)
    root.after(0,refresh)

def start(i):
    if i in active: return
    if not channels[i]['files']:
        messagebox.showwarning('No videos', 'Add MP4 videos first')
        return
    active.add(i)
    threading.Thread(target=work,args=(i,),daemon=True).start()
    refresh()

def stop(i):
    active.discard(i)
    p=processes.get(i)
    if p:
        if not channels[i]['resume']: channels[i]['position']=0
        try: p.terminate()
        except OSError: pass
    save()
    refresh()

def checkpoint():
    for i in list(active):
        if i in processes and i in started:
            now=time.monotonic()
            channels[i]['position']+=max(0,now-started[i])
            started[i]=now
    save()
    root.after(5000,checkpoint)

root=tk.Tk()
root.title('ZYAD GROUP TV Playout — 32 Channels')
root.geometry('1130x740')
selected=0
status=tk.StringVar(value='Ready')
head=ttk.Frame(root,padding=10);head.pack(fill='x')
ttk.Label(head,text='ZYAD GROUP | TV PLAYOUT',font=('Segoe UI',18,'bold')).pack(side='left')
ttk.Button(head,text='Stop All',command=lambda:[stop(i) for i in list(active)]).pack(side='right',padx=5)
ttk.Button(head,text='Start All',command=lambda:[start(i) for i in range(32) if channels[i]['files']]).pack(side='right')
body=ttk.PanedWindow(root,orient='horizontal');body.pack(fill='both',expand=True,padx=10)
left=ttk.Frame(body);right=ttk.Frame(body,padding=12)
body.add(left,weight=1);body.add(right,weight=3)
buttons=[]
for i in range(32):
    b=ttk.Button(left,text=f'CH {i+1:02}',command=lambda i=i:choose(i),width=13)
    b.grid(row=i//4,column=i%4,padx=2,pady=4)
    buttons.append(b)
fields={}
form=ttk.Frame(right);form.pack(fill='x')
for row,(key,label) in enumerate([('name','Channel name'),('ip','UDP multicast IP'),('port','UDP port'),('video_kbps','Video bitrate (kbps)'),('audio_kbps','Audio bitrate (kbps)'),('text','Overlay text')]):
    ttk.Label(form,text=label).grid(row=row,column=0,sticky='w',pady=5)
    v=tk.StringVar();fields[key]=v
    ttk.Entry(form,textvariable=v,width=52).grid(row=row,column=1,sticky='ew',padx=8)
form.columnconfigure(1,weight=1)
mode=tk.StringVar()
ttk.Label(form,text='Video mode').grid(row=6,column=0,sticky='w')
ttk.Combobox(form,textvariable=mode,values=['copy','encode'],state='readonly').grid(row=6,column=1,sticky='ew',padx=8)
resume=tk.BooleanVar();loop=tk.BooleanVar()
ttk.Checkbutton(right,text='Resume from saved position after power loss (approximate)',variable=resume).pack(anchor='w')
ttk.Checkbutton(right,text='Loop playlist',variable=loop).pack(anchor='w')
ttk.Label(right,text='MP4 playlist (in order)').pack(anchor='w',pady=(10,2))
playlist=tk.Listbox(right,height=10);playlist.pack(fill='both',expand=True)

def apply():
    c=channels[selected]
    for k,v in fields.items():c[k]=v.get()
    for k in ('port','video_kbps','audio_kbps'):
        try:c[k]=int(c[k])
        except ValueError: pass
    c['mode']=mode.get();c['resume']=resume.get();c['loop']=loop.get()
    save()

def populate():
    c=channels[selected]
    for k,v in fields.items():v.set(str(c[k]))
    mode.set(c['mode']);resume.set(c['resume']);loop.set(c['loop'])
    playlist.delete(0,'end')
    for p in c['files']:playlist.insert('end',Path(p).name)
    refresh()

def choose(i):
    global selected
    apply();selected=i;populate()

def add():
    apply()
    paths=filedialog.askopenfilenames(filetypes=[('MP4 video','*.mp4')])
    channels[selected]['files'].extend(paths);save();populate()

def remove():
    c=channels[selected]
    for idx in reversed(playlist.curselection()):c['files'].pop(idx)
    c['index']=0;c['position']=0;save();populate()

def move(d):
    c=channels[selected];s=playlist.curselection()
    if not s:return
    a=s[0];b=a+d
    if not 0<=b<len(c['files']):return
    c['files'][a],c['files'][b]=c['files'][b],c['files'][a]
    save();populate();playlist.selection_set(b)

def copy_settings():
    apply();src=channels[selected]
    for i,c in enumerate(channels):
        if i!=selected:
            for k in ('video_kbps','audio_kbps','mode','resume','loop'):c[k]=src[k]
    save();status.set('Encoding settings copied to all other channels')

bar=ttk.Frame(right);bar.pack(fill='x',pady=10)
for label,fn in [('Add MP4',add),('Remove',remove),('Up',lambda:move(-1)),('Down',lambda:move(1)),('Save',apply),('Copy Settings',copy_settings),('Start',lambda:(apply(),start(selected))),('Stop',lambda:stop(selected))]:
    ttk.Button(bar,text=label,command=fn).pack(side='left',padx=2)
ttk.Label(root,textvariable=status,padding=10).pack(fill='x')
def refresh():
    status.set(f'Active: {len(active)}/32 | Selected: CH {selected+1:02} | Settings: {CONFIG}')
    for i,b in enumerate(buttons):b.configure(text=f'CH {i+1:02} '+('ON' if i in active else 'OFF'))
def close():
    apply()
    for i in list(active):stop(i)
    root.destroy()
root.protocol('WM_DELETE_WINDOW',close)
populate();root.after(5000,checkpoint);root.mainloop()
