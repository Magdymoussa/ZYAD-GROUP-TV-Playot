# ZYAD GROUP TV Playout — initial build

Windows GUI with 32 channel slots, ordered MP4 playlists, per-channel UDP MPEG-TS, stream copy or x264/AAC encoding, text overlay, saved settings, and approximate resume checkpoints.

## Build from phone
Upload the project files (including `.github/workflows/build.yml`) to the repository root. In GitHub go to **Actions > Build Windows EXE > Run workflow**. When finished, download the artifact.

## Run
Put a compatible **ffmpeg.exe** next to the EXE (or add FFmpeg to PATH). FFmpeg is not bundled. Configure channels and add MP4 files on the Windows computer. Use **copy** for minimal CPU; use **encode** for video bitrate control and text overlays. Output addresses are sample multicast values.

## Important limitations
- **Windows 8 x64 is not verified**. The workflow builds on Windows Server 2022, and its output may not run on Windows 8. Build and test on a Windows 8-compatible environment before relying on it.
- 32 simultaneous streams are **not tested** and may exceed PC CPU/network resources.
- Resume is approximate (5-second checkpoints), not frame-accurate. Stream duration is estimated from elapsed time.
- Logo overlay and automatic startup are **not implemented** in this first code version.
- MP4 codecs in stream-copy mode must be compatible with MPEG-TS and the modulator. Audio/video codec and bitrate must be tested with SATLINK ST-8631.
- FFmpeg errors may require running a command separately for diagnosis; logs are not yet captured.
- This is a functional starting implementation, **not a finished production release**.
